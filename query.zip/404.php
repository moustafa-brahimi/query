<?php get_header(); ?>



<div id="content" class="not-found-page col-xs-12">



	<h3 class="title-404" > <?php esc_html_e( "404", "query" ); ?> </h3>

	<h3 class="not-found" > <?php esc_html_e( "the page that you're looking for doesn't exists", "query" ); ?> </h3>



</div>



<?php get_footer(); ?>

